# nutrition table > 2024-06-06 12:42am
https://universe.roboflow.com/lizazaza/nutrition-table

Provided by a Roboflow user
License: CC BY 4.0

